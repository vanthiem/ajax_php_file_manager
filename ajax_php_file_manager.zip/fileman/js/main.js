// Free Ajax-PHP File Manager - from: http://coursesweb.net/
var phpfile = 'fileman/index.php';

// to perform Ajax requests
function ajaxRe(Url, datasend, callback) {
  $.ajax({
    url: Url,
    type: 'POST',
    data: datasend,
    dataType: 'json',
    complete: function(resp) {
      if(resp.status == 200) {  // file was accessed
        // if JSON format response, pass it to callback function, else, show text response
        if(resp.responseJSON) callback(resp.responseJSON);
        else alert(resp.responseText);
      }
      else alert('Error: '+ resp.status +' - '+ resp.statusText);
    }
  });
}

var cDir = false;    // object with current dir
var cFile = false;    // object with current file
var current_dir = '';    // data-path of current dir (to not ajax request if click on same dir)
var current_file = '';    // data-path of current file (to not ajax request if click on same file)
var is_move = 0;    // if not 0 (Drag-Move), not refresh dir in Files.Move() / refresh only when Paste (is 0)

function selectFile(item){
  if($(item).attr('data-path') == current_file) return false;
  else {
    current_file = $(item).attr('data-path');
    $('#pnlFileList li').removeClass('selected');
    $(item).prop('class', 'selected');
    if($('#pnlFileList .selected').length > 0) cFile = new File($('#pnlFileList .selected').attr('data-path'));
    statusBarFile(item);
  }
}

// set status-bar
function statusBarFile(item){
    var html = '<span class="dir_name">'+ cDir.name +'</span>: '+ fmUtils.GetFilename($(item).attr('data-path'));
    html += ' ('+t('Size')+': '+fmUtils.FormatFileSize($(item).attr('data-size'));
    if($(item).attr('data-w') > 0) html += ', '+t('Dimensions')+':'+$(item).attr('data-w')+'x'+$(item).attr('data-h');
    html += ')';
    $('#pnlStatus').html(html);
}
function selectDir(item){
  var sel_dir = $(item).parent('li').attr('data-path');
  if(sel_dir == current_dir) return false;
  else {
    var d = Directory.Parse(sel_dir);
    if(d) {
      current_dir = sel_dir;
      d.Select();
      cFile = false;
      if($('#pnlDirList .selected')) cDir = Directory.Parse($('#pnlDirList .selected').closest('li').attr('data-path'));    // get Selected-Dir
    }
  }
}

/* Start Drag-Drop */
function startDragDir(){
  // empty
}
function startDragFile(){
  selectFile(this);
}
function dragFileOver(){
  $(this).children('img.dir').attr('src', fm_dir + 'images/folder-green.png');
}
function dragFileOut(){
  $('#pnlDirList').find('img.dir').attr('src', fm_dir + 'images/folder.png');
}
function makeDragFile(e){
  var f = new File($(e.target).closest('li').attr('data-path'));
  var setsrc = f.bigIcon;    // fm_dir + f.bigIcon;
  return '<div class="pnlDragFile" data-path="'+f.fullPath+'"><img src="'+setsrc+'" align="absmiddle">&nbsp;'+f.name+'</div>';
}
function makeDragDir(e){
  var f = new Directory($(e.target).attr('data-path')?$(e.target).attr('data-path'):$(e.target).closest('li').attr('data-path'));
  return '<div class="pnlDragDir" data-path="'+f.fullPath+'"><img src="'+fm_dir + 'images/folder.png" align="absmiddle">&nbsp;'+f.name+'</div>';
}
/* End Drag-Drop */

/* Dir and File acction */
function moveDir(e, ui, obj){
  var dir = Directory.Parse(ui.draggable.attr('data-path'));
  var target = Directory.Parse($(obj).parent('li').attr('data-path'));
  if($('[data-path="'+ dir.fullPath +'"]').parents('li').length < 1 && FmConf.MOVE_ROOT == 0) alert(t('E_CannotMoveRoot'));
  else if(target.fullPath != dir.path) dir.Move(target.fullPath);
}
function moveFile(e, ui, obj){
  var f = new File(ui.draggable.attr('data-path'));
  var d = Directory.Parse($(obj).parent('li').attr('data-path'));
  var src = Directory.Parse(f.path);
  if(f.path != d.fullPath) {
    is_move = 1;
    f.Move(d.fullPath);
  }
}
function moveObject(e, ui){
  e.stopPropagation();
  if(ui.draggable.hasClass('directory')) moveDir(e, ui, this);
  else moveFile(e, ui, this);
  dragFileOut();
}
function clickFirstOnEnter(elId){
  $('#'+elId).unbind('keypress');
  $('.actions span, .actions input').each(function(){this.blur();});
  $('#'+elId).keypress(function(e) {
    if (e.keyCode == $.ui.keyCode.ENTER) {
      e.stopPropagation();
      $(this).parent().find('.ui-dialog-buttonset button').eq(0).trigger('click');
    }
  });
}
function createDir(){
  if(!cDir) return;
  clickFirstOnEnter('pnlDirName');
  $('#txtDirName').val('');

  var dialogButtons = {};
  dialogButtons[t('CreateDir')] = function(){
    var newName = $.trim($('#txtDirName').val());
    if(!newName) alert(t('E_MissingDirName'));
    cDir.Create(newName)
  };
  dialogButtons[t('Cancel')] = function(){$('#pnlDirName').dialog('close');};
  $('#pnlDirName').dialog({title: t('T_CreateDir'),modal:true,buttons:dialogButtons});
}
function addFile(){
  clickFirstOnEnter('dlgAddFile');

  var dialogButtons = {};
  dialogButtons[t('Upload')] = function(){
    if(!$('#fileUploads').val()) alert(t('E_SelectFiles'));
    else{
      document.forms['addfile'].action = phpfile +'?ca=upload';
      document.forms['addfile'].d.value = cDir.fullPath;
      document.forms['addfile'].submit();
      $('#dlgAddFile').dialog('close');
      return false;
    }
  };
  dialogButtons[t('Cancel')] = function(){$('#dlgAddFile').dialog('close');};

  $('#dlgAddFile').dialog({title:t('T_AddFile'),modal:true,buttons:dialogButtons});
}
function fileUploaded(resp){
   var d = Directory.Parse($('#hdDir').val());
   d.dirFiles(true);
  alert(t(resp));
}
function renameDir(){
  if(!cDir) return;
  else if($('[data-path="'+ cDir.fullPath +'"]').parents('li').length < 1 && FmConf.RENAME_ROOT == 0) alert(t('E_CannotRenameRoot'));
  else {
    clickFirstOnEnter('pnlDirName');
    $('#txtDirName').val(cDir.name);

    var dialogButtons = {};
    dialogButtons[t('Rename')] = function(){
      var newName = $.trim($('#txtDirName').val());
      if(!newName) alert(t('E_MissingDirName'));
      else if(newName == cDir.name) alert(t('E_SameName'));
      else cDir.Rename(newName);
    };
    dialogButtons[t('Cancel')] = function(){$('#pnlDirName').dialog('close');};

    $('#pnlDirName').dialog({title:t('T_RenameDir'),modal:true,buttons:dialogButtons});
    fmUtils.SelectText('txtDirName', 0, new String(cDir.name).length);
  }
}
function renameFile(){
  if(!cFile) alert(t('E_NoFileSelected'));
  else {
    clickFirstOnEnter('pnlRenameFile');
    $('#txtFileName').val(cFile.name);

    var dialogButtons = {};
    dialogButtons[t('Rename')] = function(){
      var newName = $.trim($('#txtFileName').val());
      if(!newName) alert(t('E_MissFname'));
      else if(newName == cFile.name) alert(t('E_SameName'));
      else cFile.Rename(newName);
    };
    dialogButtons[t('Cancel')] = function(){$('#pnlRenameFile').dialog('close');};

    $('#pnlRenameFile').dialog({title:t('T_RenameFile'),modal:true,buttons:dialogButtons});
    if(cFile.name.lastIndexOf('.') > 0) fmUtils.SelectText('txtFileName', 0, cFile.name.lastIndexOf('.'));
  }
}
function deleteDir(path){
  if($('[data-path="'+ cDir.fullPath +'"]').parents('li').length < 1 && FmConf.DEL_ROOT == 0) alert(t('E_CannotDelRoot'));
  else {
    if(path) cDir = Directory.Parse(path);
    if(cDir && confirm(t('Q_DeleteFolder'))) cDir.Delete();
  }
  clearClipboard();
}
function deleteFile(){
  if(!cFile) alert(t('E_NoFileSelected'));
  else {
    if(confirm(t('Q_DeleteFile'))) cFile.Delete();
    clearClipboard();
  }
}
function previewFile(){
  if(!cFile) alert(t('E_NoFileSelected'));
  else window.open(cFile.fullPath);
}
function downloadFile(){
  if(!cFile) alert(t('E_NoFileSelected'));
  else window.frames['frmUploadFile'].location.href = phpfile +'?ca=downloadfile&d='+ cFile.fullPath;
}
function downloadDir(){
  window.frames['frmUploadFile'].location.href = phpfile +'?ca=downloaddir&d='+ cDir.fullPath;
}
/* End Dir and File actions */

/* Menu */
function showMenu(e, el) {
  e.stopPropagation();
  e.preventDefault();
  if(!el) var el = null;
  closeMenus(el);
  var menu_id = (el == 'file') ? '#menuFile' : '#menuDir';
  var t = e.pageY - $(menu_id).height() + 33;
  if(t < 0)  t = 0;
  $(menu_id).css({
    top: t+'px',
    left: e.pageX+'px'
  }).show();
}
function closeMenus(el){
  if(!el || el == 'dir') $('#menuFile').fadeOut();
  if(!el || el == 'file') $('#menuDir').fadeOut();
}
function selectFirst(){
  var item = $('#pnlDirList li:first').children('div').first();
  if(item.length > 0) selectDir(item);
  else window.setTimeout('selectFirst()', 300);
}
function tooltipContent(){
  if($('#menuFile').is(':visible')) return '';
  var html = '';
  var f = File.Parse($(this).attr('data-path'));
  if($('#hdViewType').val() == 'thumb' && f.type == 'image'){
    html = f.fullPath+'<br><span class="filesize">'+t('Size')+': '+fmUtils.FormatFileSize(f.size) + ' '+t('Dimensions')+': '+f.width+'x'+f.height+'</span>';
  }
  else if(f.type == 'image'){
    if(FmConf.GENERATETHUMB){
      imgUrl = fmUtils.AddParam(FmConf.GENERATETHUMB, 'f', f.fullPath);
      imgUrl = fmUtils.AddParam(imgUrl, 'width', FmConf.PREVIEW_THUMB_WIDTH);
      imgUrl = fmUtils.AddParam(imgUrl, 'height', FmConf.PREVIEW_THUMB_HEIGHT);
    }
    else imgUrl = f.fullPath;
    html = '<img src="'+imgUrl+'" class="imgPreview"><br>'+f.name+' <br><span class="filesize">'+t('Size')+': '+fmUtils.FormatFileSize(f.size) + ' '+t('Dimensions')+': '+f.width+'x'+f.height+'</span>';
  }
  else html = f.fullPath+' <span class="filesize">'+t('Size')+': '+fmUtils.FormatFileSize(f.size) + '</span>';
  return html;
}
function filterFiles(){
  var str = $('#txtSearch').val();
  $('#pnlSearchNoFiles').hide();
  if($('#pnlFileList li').length == 0) return;
  if(!str){
    $('#pnlFileList li').show();
    return;
  }
  var i = 0;
  $('#pnlFileList li').each(function(){
    var name = $(this).children('.name').text();
    if(name.toLowerCase().indexOf(str.toLowerCase()) > -1){
      i++;
      $(this).show();
    }
    else{
      $(this).removeClass('selected');
      $(this).hide();
    }
  });
  if(i == 0) $('#pnlSearchNoFiles').show();
}
function sortFiles(){
  if(!cDir) return;
  cDir.dirFiles();
  filterFiles();
  switchView($('#hdViewType').val());
}
function switchView(t){
  if(t == $('#hdViewType').val()) return;
  if(!t) t = $('#hdViewType').val();
  $('.btnView').removeClass('selected');
  if(t == 'thumb'){
    $('#pnlFileList .icon').attr('src', fm_dir + 'images/blank.gif');
    $('#pnlFileList').addClass('thumbView');
    if($('#dynStyle').length == 0){
      $('head').append('<style id="dynStyle" />');
      var rules = 'ul#pnlFileList.thumbView li{width:'+FmConf.THUMBS_VIEW_WIDTH+'px;}';
      rules += 'ul#pnlFileList.thumbView li{height:'+(parseInt(FmConf.THUMBS_VIEW_HEIGHT) + 20)+'px;}';
      rules += 'ul#pnlFileList.thumbView .icon{width:'+FmConf.THUMBS_VIEW_WIDTH+'px;}';
      rules += 'ul#pnlFileList.thumbView .icon{height:'+FmConf.THUMBS_VIEW_HEIGHT+'px;}';
      $('#dynStyle').html(rules);
    }
    $('#pnlFileList li').each(function(){

      var imgUrl = $(this).attr('data-icon-big');
      if(FmConf.GENERATETHUMB && fmUtils.IsImage($(this).attr('data-path'))){
        imgUrl = fmUtils.AddParam(FmConf.GENERATETHUMB, 'f', imgUrl);
        imgUrl = fmUtils.AddParam(imgUrl, 'width', FmConf.THUMBS_VIEW_WIDTH);
        imgUrl = fmUtils.AddParam(imgUrl, 'height', FmConf.THUMBS_VIEW_HEIGHT);
      }
      $(this).children('.icon').css('background-image', 'url('+imgUrl+')');
      $(this).tooltip('option', 'show', {delay:100});
    });
    $('#btnThumbView').addClass('selected');
  }
  else{
    $('#pnlFileList').removeClass('thumbView');
    $('#pnlFileList li').each(function(){
      $(this).children('.icon').css('background-image','').attr('src', $(this).attr('data-icon'));
      $(this).tooltip('option', 'show', {delay:500});
    });
    $('#btnListView').addClass('selected');
  }
  $('#hdViewType').val(t);
}

// cut, copy, paste Dir & File
function cutDir(){
  if(cDir){
    if($('[data-path="'+ cDir.fullPath +'"]').parents('li').length < 1 && FmConf.MOVE_ROOT == 0) alert(t('E_CannotMoveRoot'));
    else {
      setClipboard('cut', cDir);
      cDir.GetElement().addClass('pale');
    }
  }
}
function copyDir(){
  if(cDir) setClipboard('copy', cDir);
}
function cutFile(){
  if(!cFile) alert(t('E_NoFileSelected'));
  else {
    setClipboard('cut', cFile);
    cFile.GetElement().addClass('pale');
  }
}
function copyFile(){
  if(!cFile) alert(t('E_NoFileSelected'));
  else setClipboard('copy', cFile);
}
function pasteToFiles(e, el){
  if($(el).hasClass('pale')){
    e.stopPropagation();
    return false;
  }
  if(!cDir) cDir = Directory.Parse($('#pnlDirList li:first').children('div').first());
  if(cDir && clipBoard && clipBoard.obj){
    if(clipBoard.action == 'copy') clipBoard.obj.Copy(cDir.fullPath);
    else{
      clipBoard.obj.Move(cDir.fullPath);
      clearClipboard();
    }
  }
  return true;
}
function pasteToDirs(e, el){
  if($(el).hasClass('pale')){
    e.stopPropagation();
    return false;
  }
  if(!cDir) cDir = Directory.Parse($('#pnlDirList li:first').children('div').first());
  if(clipBoard && cDir){
    if(clipBoard.action == 'copy') clipBoard.obj.Copy(cDir.fullPath);
    else{
      clipBoard.obj.Move(cDir.fullPath);
      clearClipboard();
      cDir.dirFiles(true);
    }
  }
  else alert('error');
  return true;
}
var clipBoard = null;
function Clipboard(a, obj){
  this.action = a;
  this.obj = obj;
}
function clearClipboard(){
  $('#pnlDirList li').removeClass('pale');
  $('#pnlFileList li').removeClass('pale');
  clipBoard = null;
  $('.paste').addClass('pale');
  $('.paste_elm').text('');
  $('#mnuDirPaste, #mnuFilePaste').hide();
}
function setClipboard(a, obj){
  clearClipboard();
  if(obj){
    clipBoard = new Clipboard(a, obj);

    // add name of current cut /copyed dir /file to Paste in right-menu of Dirs and Files
    // make Paste visible according to "obj" (if has 'ext' propery if Fiile)
    $('.paste_elm').text(clipBoard.obj.name +(obj.ext ? '' : '/'));
    if(obj.ext) {
      $('#mnuDirPaste, #mnuFilePaste').css('display','block');
    }
    else {
      $('#mnuFilePaste .paste_elm').text('');
      $('#mnuFilePaste').hide();
      $('#mnuDirPaste').css('display','block');
    }

    $('.paste').removeClass('pale');
  }
}

/* EDIT FILE */
function editFile(){
  if(!cFile) alert(t('E_SelectEditFile'));
  else {
    var is_e = 0;
    var ar_ext = FmConf.EDITFILE.split(' ');
    var nr_ae = ar_ext.length;
    for(var i=0; i<nr_ae; i++) {
      if(ar_ext[i] == cFile.ext) {
        is_e = 1; break;
      }
    }
    if(is_e == 0) alert(t('E_FileExtensionForbidden'));
    else {
      $.ajax({
        url: cFile.fullPath,
        async:false,
        cache: false,
        success: function(data){
          document.getElementById('f_ed_f').value = cFile.fullPath;
          document.getElementById('fc').value = data;
          document.getElementById('btnSendCnt').focus();
          document.getElementById('fc').focus();
          $('#f_editf').dialog({modal:true, title: t('T_ContentOf') +': '+ cFile.name, width:'95%'});     // open modal with form
        },
        error: function(data){
          alert(t('E_UnableRead') +': '+ this.fullPath);
        }
      });
    }
  }
}
function sendCntFile(frm) {
  ajaxRe(phpfile, 'ca=editfile&f='+ frm.f.value +'&fc='+ frm.fc.value.replace(/&/g, '%26'), function(resp){
    closeEditFile();
    if(resp.ok && resp.size && resp.time) {
      // actualize size, time in html and file object
      $('li[data-path="'+cFile.fullPath+'"]').attr('data-size', resp.size);
      $('li[data-path="'+cFile.fullPath+'"]').attr('data-time', resp.time);
      $('li[data-path="'+cFile.fullPath+'"] .size').text(fmUtils.FormatFileSize(resp.size));
      $('li[data-path="'+cFile.fullPath+'"] .time').text(fmUtils.FormatDate(new Date(resp.time * 1000)));
      cFile.size = resp.size;
      cFile.time = resp.time;
      statusBarFile($('#pnlFileList .selected'));
      alert(t(resp.ok));
    }
    else alert(resp[0]);
  });
  return false;
}
function closeEditFile() {
  document.getElementById('f_ed_f').value = '';
  document.getElementById('fc').value = '';
 $('#f_editf').dialog('close');
}
/* END EDIT FILE */

// set the height of fileman files area
function ResizeLists(){
  var tmp = $(window).innerHeight() - $('#fileActions .actions').outerHeight() - 70;
  $('.scrollPane').css('height', tmp);
}