// Free Ajax-PHP File Manager - from: http://coursesweb.net/
var dir_tree_ok = 0;    // 1 after load dir-tree and files of MAIN_ROOT
function Directory(fullPath, numDirs, numFiles){
  var me = this;
  if(!fullPath) fullPath = '';
  this.fullPath = fullPath.replace('//', '/').replace(/\/$/, '');
  this.name = fmUtils.GetFilename(fullPath);
  if(!this.name) {
    var sp_root = this.fullPath.replace(/\/$/, '').split('/');
    var nr_sr = sp_root.length
    this.name = sp_root[nr_sr - 1];
  }
  this.path = fmUtils.GetPath(fullPath);
  this.dirs = (numDirs ? numDirs : 0);
  this.files = (numFiles ? numFiles : 0);
  this.filesList = new Array();

  this.Show = function(){
    var html = me.GetHtml();
    var el = $('li[data-path="'+this.path+'"]');
    if(el.length == 0)  el = $('#pnlDirList');
    else {
      if(el.children('ul').length == 0) el.append('<ul></ul>');
      el = el.children('ul');
    }
    if(el){
      el.append(html);
      this.SetEvents();
    }
  };
  this.SetEvents = function(){
    var el = this.GetElement();
    el.draggable({helper:makeDragDir,start:startDragDir,cursorAt: { left: 10 ,top:10},delay:200});
    el = el.children('div');
    el.click(function(e){ selectDir(this);});

    el.bind('contextmenu', function(e) {
      selectDir(this);
      showMenu(e, 'dir');
      return false;
    });

    el.droppable({
      drop:moveObject, over:dragFileOver, out:dragFileOut,
      hoverClass: "hgh_drop"
    });
    el = el.children('.dirPlus');
    el.click(function(e){
      e.stopPropagation();
      var d = Directory.Parse($(this).closest('li').attr('data-path'));
      d.Expand();
    });
  };
  this.GetHtml = function(){
    if(root_dir[me.fullPath]) {
     var html = '<li data-path="'+this.fullPath+'" data-dirs="'+this.dirs+'" data-files="'+this.files+'" class="directory isroot">';
     if(this.dirs > 0) html += '<div>&bull;<img src="'+fm_dir + 'images/dir-plus.png" class="dirPlus" width="9" height="9">';
     else html += '<div>&bull; <img src="'+ fm_dir + 'images/blank.gif" class="dirPlus blankRoot" width="9" height="9">';
     html += ' <strong class="name">'+this.name+'&nbsp;('+this.files+')</strong></div>';
     html += '</li>';
    }
    else {
     var html = '<li data-path="'+this.fullPath+'" data-dirs="'+this.dirs+'" data-files="'+this.files+'" class="directory">';
     html += '<div><img src="'+ fm_dir + 'images/'+(this.dirs > 0 ? 'dir-plus.png' : 'blank.gif')+'" class="dirPlus" width="9" height="9">';
     html += '<span class="name">'+ this.name+'&nbsp;('+this.files+')</span></div>';
     html += '</li>';
    }
    return html;
  };
  this.SetStatusBar = function(){
    $('#pnlStatus').html('<span class="dir_name">'+ this.name +'</span>: '+ this.files +' '+(this.files == 1 ? t('file') : t('files')));
  };
  this.Select = function(){
    var el = this.GetElement();
    el.children('div').addClass('selected');
    $('#pnlDirList li[data-path!="'+this.fullPath+'"] > div').removeClass('selected');
    this.SetStatusBar();
    var p = this.GetParent();
    while(p){
      p.Expand(true);
      p = p.GetParent();
    }
    this.Expand(true);
    if(dir_tree_ok == 1) this.dirFiles(true);    // to not call dirFles on 1st load (dir files already added in dir-tree response)
    else dir_tree_ok = 1;    // set 1 to can load the next requests
  };
  this.GetElement = function(){
    return  $('li[data-path="'+this.fullPath+'"]');
  };
  this.IsExpanded = function(){
    var el = this.GetElement().children('ul');
    return (el && el.is(":visible"));
  };
  this.IsListed = function(){
    if($('#hdDir').val() == this.fullPath) return true;
    else return false;
  };
  this.GetExpanded = function(el){
    var ret = new Array();
    if(!el) el = $('#pnlDirList');
    el.children('li').each(function(){
      var path = $(this).attr('data-path');
      var d = new Directory(path);
      if(d){
        if(d.IsExpanded() && path) ret.push(path);
        ret = ret.concat(d.GetExpanded(d.GetElement().children('ul')));
      }
    });

    return ret;
  };
  this.RestoreExpanded = function(expandedDirs){
    for(i = 0; i < expandedDirs.length; i++){
      var d = Directory.Parse(expandedDirs[i]);
      if(d) d.Expand(true);
    }
  };
  this.GetParent = function(){
    return Directory.Parse(this.path);
  };
  this.SetOpened = function(){
    var li = this.GetElement();
    if(li.find('li').length < 1) li.children('div').children('.dirPlus').prop('src', fm_dir + 'images/blank.gif');
    else if(this.IsExpanded()) li.children('div').children('.dirPlus').prop('src', fm_dir + 'images/dir-minus.png');
    else li.children('div').children('.dirPlus').prop('src', fm_dir + 'images/dir-plus.png');
  };
  this.Update = function(newPath){
    var el = this.GetElement();
    if(newPath){
      this.fullPath = newPath;
      this.name = fmUtils.GetFilename(newPath);
      if(!this.name) {
        var sp_root = this.fullPath.replace(/\/$/, '').split('/');
        var nr_sr = sp_root.length
        this.name = sp_root[nr_sr - 1];
      }
      this.path = fmUtils.GetPath(newPath);
    }
    el.attr('data-path', this.fullPath);
    el.attr('data-dirs', this.dirs);
    el.attr('data-files', this.files);
    el.children('div').children('.name').html(this.name+' ('+this.files+')');
    this.SetOpened();
  };

  // gets all dirs and files of 1st root, from php
  this.loadDir = function(selectedDir){
    ajaxRe(phpfile, 'ca=dirtree', function(resp){
      var expanded = me.GetExpanded();
      $('#pnlDirList').children('li').remove();
      if(resp.dirs) {
        var dirs = resp.dirs;
        for(i = 0; i < dirs.length; i++){
          var d = new Directory(dirs[i].p, dirs[i].d, dirs[i].f);
          d.Show();
        }
        me.RestoreExpanded(expanded);
        var cDir = Directory.Parse(selectedDir);
      }
      if(resp.files && dir_tree_ok == 0) me.setDirFiles(resp.files);
      else {
        var d = Directory.Parse(selectedDir);
        if(d) d.Select();
      }
    });
  };
  this.Expand = function(show){
    var li = this.GetElement();
    var el = li.children('ul');
    if(this.IsExpanded() && !show) el.hide();
    else el.show();

    this.SetOpened();
  };
  this.Create = function(newName){
    if(!newName) return false;
    ajaxRe(phpfile, 'ca=createdir&d='+ this.fullPath +'&n='+ newName, function(resp){
      if(resp[0].toLowerCase() == 'ok'){
        $('#pnlDirName').dialog('close');
        current_dir = fmUtils.MakePath(me.fullPath, newName);
        me.loadDir(current_dir);

        // actualize in object
        me.fullPath = current_dir;
        me.name = newName;
      }
      else alert(resp[0]);
    });
  };
  this.Delete = function(){
    ajaxRe(phpfile, 'ca=deletedir&d='+ this.fullPath, function(resp){
      if(resp[0].toLowerCase() == 'ok'){
        var parent = me.GetParent();
        if(parent) {
          parent.dirs--;
          parent.Update();
          parent.Select();
          me.GetElement().remove();

          // actualize in object
          current_dir = parent.fullPath;
          me.fullPath = current_dir;
          me.name = parent.name;
        }
        else me.dirFiles(true);
      }
      else alert(resp[0]);
    });
  };
  this.Rename = function(newName){
    if(!newName) return false;
    var old_path = this.fullPath;
    ajaxRe(phpfile, 'ca=renamedir&d='+ old_path +'&n='+ newName, function(resp){
      if(resp[0].toLowerCase() == 'ok'){
        $('#pnlDirName').dialog('close');
        var newPath = old_path.replace(/[^\/]+$/i, newName);
        current_dir = newPath;

        // update 'data-path' to li children
        var me_dir = me.GetElement();
        me_dir.find('li').each(function() {
          var get_data_path = $(this).attr('data-path');
          var new_data_path = get_data_path.replace(old_path, newPath);
          $( this ).attr('data-path', new_data_path);
        });

        me.Update(newPath);
        me.Select();
      }
      else alert(resp[0]);
    });
  };
  this.Copy = function(newPath){
    ajaxRe(phpfile, 'ca=copydir&d='+ this.fullPath +'&n='+ newPath, function(resp){
      if(resp[0].toLowerCase() == 'ok'){
        var d = Directory.Parse(newPath);
        if(d) d.loadDir(d.fullPath);
      }
      else alert(resp[0]);
    });
  };
  this.Move = function(newPath){
    if(!newPath) return false;
    ajaxRe(phpfile, 'ca=movedir&d='+ this.fullPath +'&n='+ newPath, function(resp){
      if(resp[0].toLowerCase() == 'ok') {
        current_dir = fmUtils.MakePath(newPath, me.name); 
        me.loadDir(current_dir);
        cDir.name = me.name;
        cDir.fullPath = current_dir;
      }
      else alert(resp[0]);
    });
  };
  this.dirFiles = function(refresh){
    $('#pnlLoading').show();
    $('#pnlEmptyDir').hide();
    $('#pnlFileList').hide();
    $('#pnlSearchNoFiles').hide();
    this.LoadFiles(refresh);
  };
  this.FilesLoaded = function(filesList){
    filesList = this.SortFiles(filesList);
    $('#pnlFileList').html('');
    for(i = 0; i < filesList.length; i++){
      var f = filesList[i];
      f.Show();
    }
    $('#hdDir').val(this.fullPath);
    $('#pnlLoading').hide();
    if($('#pnlFileList').children('li').length == 0) $('#pnlEmptyDir').show();
    this.files = $('#pnlFileList').children('li').length;
    this.Update();
    this.SetStatusBar();
    filterFiles();
    switchView();
    $('#pnlFileList').show();
  };

  this.setDirFiles = function(files){
    var ret = [];
    for(i = 0; i < files.length; i++){
      ret.push(new File(files[i].p, files[i].s, files[i].t, files[i].w, files[i].h));
    }
    me.FilesLoaded(ret);
  }
  this.LoadFiles = function(refresh){
    var ret = new Array();
    if(!this.IsListed() || refresh) ajaxRe(phpfile, 'ca=dirfiles&d='+ this.fullPath, this.setDirFiles);
    else{
      $('#pnlFileList li').each(function(){
        ret.push(new File($(this).attr('data-path'), $(this).attr('data-size'), $(this).attr('data-time'), $(this).attr('data-w'), $(this).attr('data-h')));
      });
      me.FilesLoaded(ret);
    }

    return ret;
  };

  this.toSort = function(a, b, type, order){
    var x = (order == 'desc'? 0 : 2)
    a = (type == 'name') ? a[type].toLowerCase() : parseInt(a[type]);
    b = (type == 'name') ? b[type].toLowerCase() : parseInt(b[type]);
    if(a > b) return -1 + x;
    else if(a < b) return 1 - x;
    else return 0;
  }
  this.SortFiles = function(files){
    var order = $('#ddlOrder').val();
    if(!order) order = 'name_asc';
    var type_order = order.split('_');
    files = files.sort(function(a, b){return me.toSort(a, b, type_order[0], type_order[1]);});

    return files;
  };
}
Directory.Parse = function(path){
  var ret = false;
  var li = $('#pnlDirList').find('li[data-path="'+path+'"]');
  if(li.length > 0) ret = new Directory(li.attr('data-path'), li.attr('data-dirs'), li.attr('data-files'));

  return ret;
};
