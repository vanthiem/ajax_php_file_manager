// Free Ajax-PHP File Manager - from: http://coursesweb.net/
var root_dir = {};    // object with main root directories (set in LoadConfig())

var FileTypes = new Array();
FileTypes['image'] = new Array('jpg', 'jpeg', 'png', 'gif');
FileTypes['media'] = new Array('avi', 'flv', 'swf', 'wmv', 'mp3', 'wma', 'mpg','mpeg');
FileTypes['document'] = new Array('doc', 'docx', 'txt', 'rtf', 'pdf', 'xls', 'mdb','html','htm','db');
function fmUtils(){}

/* START 1ST ACCESS */
function FmConf(){}
function FmLang(){}

// get config data, check for logg-in
fmUtils.LoadConfig = function(){
  $('#pnlLoadingDirs').show();
  ajaxRe(phpfile, 'gcd=config_data&lang=1&ca=dirtree', function(resp){
    // get annd store con data
    if(resp.conf) {
      FmConf = resp.conf;
      if(resp.conf.FILES_ROOT) {
        var get_roots = resp.conf.FILES_ROOT.replace(/[ ]+/g, '');
        get_roots = get_roots.split(',');
        var nr_gr = get_roots.length;
        for(var i=0; i<nr_gr; i++) root_dir[get_roots[i].replace(/\/$/, '')] = 1;
      }
    }
    else alert('Error loading configuration');

    // store text language
    if(resp.lang) {
      FmLang = resp.lang;
      fmUtils.Translate();
    }
    else alert('Error loading language file');

    checkLoggIn(resp)  // check logg-in
  });
};

// send data to php to logg admin, recall
function loggIn(frm) {
  $('#admin_logg').dialog('close');
  ajaxRe(phpfile, 'ca=dirtree&name='+ frm.name.value +'&pass='+ frm.pass.value, function(resp){
    checkLoggIn(resp)  // check logg-in
  });
  return false;
}

// to check if admin logg-in, in ajax resp
function checkLoggIn(resp) {
  if(resp.conf && (resp.conf.LOGG_IN || resp.conf.LOGG_IN === 0)) {
    if(resp.conf.LOGG_IN == 1) {
      if(resp.dirs) {
        $('#pnlLoadingDirs').hide();
        var dirs = resp.dirs;
        for(i = 0; i < dirs.length; i++){
          cDir = new Directory(dirs[i].p, dirs[i].d, dirs[i].f);
          cDir.Show();
        }
      }
      if(resp.files && dir_tree_ok == 0) cDir.setDirFiles(resp.files);

      if(document.getElementById('admin_logg')) document.getElementById('admin_logg').outerHTML = '';    // removes loggin form from html
    }
    else {    // Not Logged
      // if no form to logg in, add it after #f_editf
      if(!document.getElementById('admin_logg')) {
        var form_logg = '<form action="#" method="post" id="admin_logg" onsubmit="return loggIn(this);"><label for="name">'+ t('Name') +': <input type="text" name="name" id="name" value="" /></label> <label for="pass">'+ t('Password') +': <input type="password" name="pass" id="pass" value="" /></label> <input type="submit" id="lg_submit" value="'+ t('Send') +'" /></form>';
        document.getElementById('f_editf').insertAdjacentHTML('afterend', form_logg);
      }
      if(resp.conf.LOGG_IN != 0) alert(resp.conf.LOGG_IN);

     $('#admin_logg').dialog({modal:true, title:t('T_LoggIn')});     // open modal with loggin form
    }
  }
  else alert(t('E_MissLI'));
}

fmUtils.Translate = function(){
  $('[data-lang-t]').each(function(){
    var key = $(this).attr('data-lang-t');
    $(this).prop('title', t(key));
  });
  $('[data-lang-v]').each(function(){
    var key = $(this).attr('data-lang-v');
    $(this).prop('value', t(key));
  });
  $('[data-lang]').each(function(){
    var key = $(this).attr('data-lang');
    if($(this).attr('id') == 'mnuDirPaste' || $(this).attr('id') == 'mnuFilePaste') $(this).html(t(key) +'<br><em class="paste_elm"></em>');
    else $(this).html(t(key));
  });
};
/* END 1ST ACCESS */

fmUtils.FixPath = function(path){
  if(!path) return '';
  var ret = path.replace(/\\/g, '');
  ret = ret.replace(/\/\//g, '/');
  ret = ret.replace(':/', '://');

  return ret;
};
fmUtils.FormatDate = function(date){
  var ret = '';
  try{
    ret = $.format.date(date, FmConf.DATEFORMAT);
  }
  catch(ex){
    alert(ex);
    ret = date.toString();
    ret = ret.substr(0, ret.indexOf('UTC'));
  }
  return ret;
};
fmUtils.GetPath = function(path){
  var ret = '';
  path = fmUtils.FixPath(path);
  if(path.indexOf('/') > -1) ret = path.substring(0, path.lastIndexOf('/'));

  return ret;
};
fmUtils.GetUrlParam = function(varName, url){
  var ret = '';
  if(!url) url = self.location.href;
  if(url.indexOf('?') > -1){
     url = url.substr(url.indexOf('?') + 1);
     url = url.split('&');
     for(i = 0; i < url.length; i++){
       var tmp = url[i].split('=');
       if(tmp[0] && tmp[1] && tmp[0] == varName){
         ret = tmp[1];
         break;
       }
     }
  }

  return ret;
};
fmUtils.GetFilename = function(path){
  var ret = path;
  path = fmUtils.FixPath(path);
  if(path.indexOf('/') > -1){
    ret = path.substring(path.lastIndexOf('/')+1);
  }

  return ret;
};
fmUtils.MakePath = function(){
  ret = '';
  if(arguments && arguments.length > 0){
    for(var i = 0; i < arguments.length; i++){
      ret += ($.isArray(arguments[i])?arguments[i].join('/'):arguments[i]);
      if(i < (arguments.length - 1)) ret += '/';
    }
    ret = fmUtils.FixPath(ret).replace(/\/$/, '');
  }

  return ret;
};
fmUtils.GetFileExt = function(path){
  path = fmUtils.GetFilename(path);
  var ret = (path.indexOf('.') > -1) ? path.substring(path.lastIndexOf('.') + 1) : '';

  return ret;
};
fmUtils.FileExists = function(path) {
  var ret = false;
  $.ajax({
    url: path,
    type: 'HEAD',
    async: false,
    dataType:'text',
    success:function(){ret = true;}
  });

  return ret;
};
fmUtils.GetFileIcon = function(path){
  ret = fm_dir + 'images/filetypes/file_extension_' + fmUtils.GetFileExt(path).toLowerCase() + '.png';
  if(!fileTypeIcons[fmUtils.GetFileExt(path).toLowerCase()]) ret = fm_dir + 'images/filetypes/unknown.png';

  return ret;
};
fmUtils.GetFileSize = function(path){
  var ret = 0;
  $.ajax({
    url: path,
    type: 'HEAD',
    async: false,
    success:function(d,s, xhr){
      ret = xhr.getResponseHeader('Content-Length');
    }
  });
  if(!ret) ret = 0;

  return ret;
};
fmUtils.GetFileType = function(path){
  var ret = fmUtils.GetFileExt(path).toLowerCase();
  if(ret == 'png' || ret == 'jpg' || ret == 'gif' || ret == 'jpeg') ret = 'image';

  return ret;
};
fmUtils.IsImage = function(path){
  if(fmUtils.GetFileType(path) == 'image') return true;
  else return false;
};
fmUtils.FormatFileSize = function(x){
  var suffix = 'B';
  if(!x) x = 0;
  if(x > 1024){
    x = x / 1024;
    suffix = 'KB';
  }
  if(x > 1024){
    x = x / 1024;
    suffix = 'MB';
  }
  x = new Number(x);
  return x.toFixed(2) + ' ' + suffix;
};
fmUtils.AddParam = function(url, n, v){
  url += (url.indexOf('?') > -1?'&':'?') + n + '='+escape(v);

  return url;
};
fmUtils.SelectText = function(field_id, start, end) {
  try{
    var field = document.getElementById(field_id);
    if( field.createTextRange ) {
      var selRange = field.createTextRange();
      selRange.collapse(true);
      selRange.moveStart('character', start);
      selRange.moveEnd('character', end-start);
      selRange.select();
    }
    else if( field.setSelectionRange ) field.setSelectionRange(start, end);
    else if( field.selectionStart ) {
      field.selectionStart = start;
      field.selectionEnd = end;
    }
    field.focus();
  }
  catch(ex){}
};
/* END fmUtils */

function t(tag){
  var ret = tag;
  if(FmLang && FmLang[tag]) ret = FmLang[tag];
  return ret;
}

// to controll show and hide tooltip on selector
function btnTooltip(selector) {
  var timeout;
  var finishTimeout = false;
  $(selector).tooltip({
     content: function(){
       return (finishTimeout) ? $(this).attr('title') : false;
     }
  });
  $(selector).mouseover(function(){
    var el = $(this);
    timeout = setTimeout(function(){
     finishTimeout = true;
     el.tooltip('open');
     finishTimeout = false;
    },80);
  });
  $(selector).mouseout(function(){
    clearTimeout(timeout);
  });
}

// instructions executed after page loaded, if File-Manager accessed from server
if(window.location.protocol.toLowerCase() == 'http:' || window.location.protocol.toLowerCase() == 'https:') {
  $(function(){
    fmUtils.LoadConfig();
    selectFirst();
    $('body').click(function(){ closeMenus();});
    if(FmConf.DEFAULTVIEW) switchView(FmConf.DEFAULTVIEW);
    btnTooltip('.actions span, .actions input');
    ResizeLists();

    document.oncontextmenu = function() {return false;};
  });
}
else alert('The File-Manager must be accessed from server.\nFor example: http://domain_name/fileman.html');