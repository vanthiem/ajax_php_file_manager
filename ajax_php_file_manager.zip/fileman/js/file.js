// Free Ajax-PHP File Manager - from: http://coursesweb.net/
function File(filePath, fileSize, modTime, w, h){
  var me = this;
  this.fullPath = filePath.replace('//', '/');
  this.type = fmUtils.GetFileType(filePath);
  this.name = fmUtils.GetFilename(filePath);
  this.ext = fmUtils.GetFileExt(filePath);
  this.path = fmUtils.GetPath(filePath);
  this.icon = fmUtils.GetFileIcon(filePath);
  this.bigIcon = this.icon.replace('filetypes', 'filetypes/big');
  this.image = filePath;
  this.size = (fileSize?fileSize:fmUtils.GetFileSize(filePath));
  this.time = modTime;
  this.width = (w? w: 0);
  this.height = (h? h: 0);
  this.Show = function(){
    html = '<li data-path="'+this.fullPath+'" data-time="'+this.time+'" data-icon="'+this.icon+'" data-w="'+this.width+'" data-h="'+this.height+'" data-size="'+this.size+'" data-icon-big="'+((this.type == 'image')?this.fullPath:this.bigIcon)+'" title="'+this.name+'">';
    html += '<img src="'+this.icon+'" class="icon">';
    html += '<span class="time">'+fmUtils.FormatDate(new Date(this.time * 1000))+'</span>';
    html += '<span class="name">'+this.name+'</span>';
    html += '<span class="size">'+fmUtils.FormatFileSize(this.size)+'</span>';
    html += '</li>';
    $('#pnlFileList').append(html);
    var li = $("#pnlFileList li:last");
    li.draggable({helper:makeDragFile,start:startDragFile,cursorAt: { left: 10 ,top:10},delay:200});
    li.click(function(e){
       selectFile(this);
    });
    li.dblclick(function(e){
       selectFile(this);
    });
    li.tooltip({show:{delay:700},track: true, content:tooltipContent});

    li.bind('contextmenu', function(e) {
      selectFile(this);
      $(this).tooltip('close');
      showMenu(e, 'file');
      return false;
    });
  };
  this.GetElement = function(){
    return  $('li[data-path="'+this.fullPath+'"]');
  };
  this.Delete = function(){
    ajaxRe(phpfile, 'ca=deletefile&f='+ this.fullPath, function(resp){
      if(resp[0].toLowerCase() == 'ok'){
        $('li[data-path="'+me.fullPath+'"]').remove();
        var d = Directory.Parse(me.path);
        if(d){
          d.files--;
          d.Update();
          d.SetStatusBar();
        }
      }
      else alert(resp[0]);
    });
  };
  this.Rename = function(newName){
    if(!newName) return false;
    ajaxRe(phpfile, 'ca=renamefile&f='+ this.fullPath +'&n='+ newName, function(resp){
      if(resp[0].toLowerCase() == 'ok'){
        var newPath = fmUtils.MakePath(this.path, newName);
        $('li[data-path="'+me.fullPath+'"] .icon').attr('src', fmUtils.GetFileIcon(newName));
        $('li[data-path="'+me.fullPath+'"] .name').text(newName);
        current_file = $('li[data-path="'+me.fullPath+'"]').attr('data-path').replace(me.name, newName);
        $('li[data-path="'+me.fullPath+'"]').attr('data-path', current_file);
        $('#pnlRenameFile').dialog('close');
        $('#pnlStatus').html($('#pnlStatus').html().replace(me.name, newName));

        // actualize in object
        cFile.fullPath = current_file;
        cFile.name = newName;
      }
      else alert(resp[0]);
    });
    return ret;
  };
  this.Copy = function(newPath){
    ajaxRe(phpfile, 'ca=copyfile&f='+ this.fullPath +'&n='+ newPath, function(resp){
      if(resp[0].toLowerCase() == 'ok'){
        var d = Directory.Parse(newPath);
        if(d){
          d.files++;
          d.Update();
          d.SetStatusBar();
          d.dirFiles(true);
        }
      }
      else alert(resp[0]);
    });
    return ret;
  };
  this.Move = function(newPath){
    ajaxRe(phpfile, 'ca=movefile&f='+ this.fullPath +'&n='+ fmUtils.MakePath(newPath, this.name), function(resp){
      if(resp[0].toLowerCase() == 'ok'){
        $('li[data-path="'+me.fullPath+'"]').remove();
        var d = Directory.Parse(me.path);
        if(d){
          d.files--;
          d.SetStatusBar();
          d = Directory.Parse(newPath);
          d.files++;
          d.Update();
          if(is_move == 0) d.dirFiles(true);    // refresh dir
          else is_move = 0;
        }
      }
      else alert(resp[0]);
    });
  };
}
File.Parse = function(path){
  var ret = false;
  var li = $('#pnlFileList').find('li[data-path="'+path+'"]');
  if(li.length > 0)
    ret = new File(li.attr('data-path'), li.attr('data-size'), li.attr('data-time'), li.attr('data-w'), li.attr('data-h'));

  return ret;
};