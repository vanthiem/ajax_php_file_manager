// Free Ajax-PHP File Manager - from: http://coursesweb.net/
// register events to buttons (id: [function, parameter])
var btn_call = {
  // btn-dirs
  btncreateDir: 'createDir',
  btnRenameDir: 'renameDir',
  btnDeleteDir: 'deleteDir',
  btnDownloadDir: 'downloadDir',

  // btn-files
  btnAddFile: 'addFile',
  btnPreviewFile: 'previewFile',
  btnRenameFile: 'renameFile',
  btnEditFile: 'editFile',
  btnDownloadFile: 'downloadFile',
  btnDeleteFile: 'deleteFile',

  // mnu-dirs
  mnuDownloadDir: 'downloadDir',
  mnuCreateDir: 'createDir',
  mnuDirCut: 'cutDir',
  mnuDirCopy: 'copyDir',
  mnuRenameDir: 'renameDir',
  mnuDeleteDir: 'deleteDir',

  // mnu-files
  mnuPreview: 'previewFile',
  mnuDownload: 'downloadFile',
  mnuFileCut: 'cutFile',
  mnuFileCopy: 'copyFile',
  mnuRenameFile: 'renameFile',
  mnuEditFile: 'editFile',
  mnuDeleteFile: 'deleteFile'
}

for(var btn_id in btn_call) {
  if(document.getElementById(btn_id)) document.getElementById(btn_id).addEventListener('click', function(e){
    window[ btn_call[this.id] ]();
  }, false);
}
// click to call functions with parameter
$('#btnListView').click(function () { switchView('list');});
$('#btnThumbView').click(function () { switchView('thumb');});
$('#mnuDirPaste').click(function (event) { return pasteToDirs(event, this);});
$('#mnuFilePaste').click(function (event) { return pasteToFiles(event, this);});

$('#ddlOrder').change(function () { sortFiles();});    // sort-list files
$('#txtSearch').change(function () { filterFiles();});    // sort-search files
$('#txtSearch').keyup(function () { filterFiles();});    // sort-search files
$('#frm_edit').submit(function () { return sendCntFile(this);});    // edit files
$('#cnc_edit').click(function () { closeEditFile(); return false;});    // cancel btn to close edit-file form

$('#dirActions .scrollPane').on('contextmenu', function(e){ showMenu(e, 'dir');  return false;});    // show menu on right-click dir area
$('#fileActions .scrollPane').on('contextmenu', function(e){ showMenu(e, 'file');  return false;});    // show menu on right-click file area